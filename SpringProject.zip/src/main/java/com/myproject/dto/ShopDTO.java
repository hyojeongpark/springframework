package com.myproject.dto;

import lombok.Data;

@Data
public class ShopDTO {
	private int num;
	private int amount;
	private String name;
	private String email;
}
